"""Run inside GPU Blender: benchmark by default, explicit --full for all frames."""
import argparse,hashlib,json,sys,time
from pathlib import Path
import bpy

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--full',action='store_true');p.add_argument('--check-only',action='store_true')
    p.add_argument('--max-seconds',type=int,default=3600)
    a=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    if a.max_seconds<=0:raise RuntimeError('max-seconds must be positive')
    s=bpy.context.scene
    assert (s.render.resolution_x,s.render.resolution_y,s.render.fps,s.frame_end)==(1080,1920,24,720)
    if bpy.app.version[:2]!=(4,3):raise RuntimeError('Use official Blender 4.3.2 to match the approved scene/look.')
    if a.check_only:
        print('CHECK ONLY: scene/profile valid; GPU availability and a complete render are not tested.');return
    preferences=bpy.context.preferences.addons['cycles'].preferences
    backend=None;devices=[]
    for candidate in ('OPTIX','CUDA'):
        try:
            preferences.compute_device_type=candidate;preferences.get_devices()
            devices=[d for d in preferences.devices if d.type==candidate]
        except (TypeError,RuntimeError):continue
        if devices:backend=candidate;break
    if not devices:raise RuntimeError('No usable NVIDIA Cycles GPU. Aborting rather than falling back to CPU.')
    chosen=devices[0]
    for device in preferences.devices:device.use=device.id==chosen.id and device.type==backend
    s.render.engine='CYCLES';s.cycles.device='GPU';s.cycles.samples=96
    s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.025;s.cycles.adaptive_min_samples=8
    s.cycles.use_denoising=True;s.cycles.denoiser='OPENIMAGEDENOISE'
    s.cycles.denoising_input_passes='RGB_ALBEDO_NORMAL';s.cycles.denoising_prefilter='ACCURATE'
    s.cycles.denoising_quality='HIGH';s.cycles.denoising_use_gpu=False
    s.render.resolution_percentage=100;s.render.use_motion_blur=True
    s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8'
    s.render.use_file_extension=True;s.render.use_border=False;s.render.use_crop_to_border=False
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    frames=range(1,721) if a.full else (49,145,241,361,481,697)
    profile={'scene_sha256':hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest(),'blender':bpy.app.version_string,
             'backend':backend,'gpu':chosen.name,'resolution':[1080,1920],'fps':24,'samples_max':96,'exposure':s.view_settings.exposure,
             'mode':'full' if a.full else 'benchmark'}
    profile_file=out/'profile.json'
    if profile_file.exists() and json.loads(profile_file.read_text())!=profile:raise RuntimeError('Output profile differs; use a new output folder.')
    profile_file.write_text(json.dumps(profile,indent=2)+'\n');started=time.monotonic();records=[]
    for frame in frames:
        if time.monotonic()-started>=a.max_seconds:raise RuntimeError('Render time guard reached. The local controller must still terminate the rental; stopping Blender alone does not end Vast billing.')
        target=out/f'{frame:04d}.png';record=out/f'{frame:04d}.json'
        if target.exists() and record.exists():
            old=json.loads(record.read_text())
            if hashlib.sha256(target.read_bytes()).hexdigest()!=old['sha256']:raise RuntimeError('Existing PNG hash mismatch')
            records.append(old);continue
        s.frame_set(frame);s.render.filepath=str(target);t=time.monotonic();bpy.ops.render.render(write_still=True)
        r={'frame':frame,'seconds':round(time.monotonic()-t,3),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
        record.write_text(json.dumps(r,indent=2)+'\n');records.append(r)
        (out/'progress.json').write_text(json.dumps({'complete':len(records),'total':len(frames),'last':r},indent=2)+'\n')
        print('GPU_FRAME',json.dumps(r),flush=True)
    summary={'profile':profile,'frames':records,'elapsed_seconds':round(time.monotonic()-started,3)}
    if not a.full:
        summary['conservative_render_hours']=round(max(r['seconds'] for r in records)*720*1.5/3600,3)
        summary['note']='Rendering only; add installation, transfers, hourly/storage/network charges and a reserve. This script never controls Vast billing.'
    (out/'render-report.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=='__main__':main()
