#!/usr/bin/env bash
# Run only inside the rented Ubuntu NVIDIA container. No Vast API key required.
set -euo pipefail
task_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$task_root"
test -f scene.blend
test -f render_brake_gpu.py
if [ "$(id -u)" != 0 ]; then
  echo 'Run inside the rental container as root.' >&2
  exit 1
fi
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl xz-utils tar python3 \
  libx11-6 libxext6 libxfixes3 libxi6 libxrender1 libxxf86vm1 libxkbcommon0 \
  libsm6 libice6 libgl1 libegl1 libxrandr2 libxcursor1 libgomp1 libdbus-1-3 \
  libwayland-client0
blender_version=4.3.2
blender_archive="blender-${blender_version}-linux-x64.tar.xz"
blender_folder="blender-${blender_version}-linux-x64"
if [ ! -x "$blender_folder/blender" ]; then
  curl --fail --location --retry 2 --connect-timeout 20 --max-time 600 \
    "https://download.blender.org/release/Blender4.3/$blender_archive" -o "$blender_archive"
  curl --fail --location --retry 2 --connect-timeout 20 --max-time 60 \
    "https://download.blender.org/release/Blender4.3/blender-${blender_version}.sha256" -o blender-checksums.sha256
  sha256sum --check --ignore-missing blender-checksums.sha256
  tar -xJf "$blender_archive"
fi
"$blender_folder/blender" --version | head -n 2
echo 'SETUP READY. Next: benchmark six frames. This installer does not manage billing.'
