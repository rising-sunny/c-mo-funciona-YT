# Freno hidráulico — preparación para Vast.ai

Presupuesto máximo autorizado: **US$10 en total**. Objetivo de planificación:
US$8 y US$2 de margen, contando preparación, alquiler, disco y transferencia.
No se ha creado una instancia, consultado saldo ni ejecutado un render en Vast.
No hay tarifas actuales ni tiempo GPU medido todavía.

## Ruta actual: PowerShell en el PC del usuario

El usuario configuró `VAST_API_KEY` en su sesión local de PowerShell y autenticó
correctamente contra `/api/v0/users/current/` (con barra final). Puede operar desde
su PC sin trasladar la clave a este chat ni modificar el entorno de Codex.
Una consulta local devolvió la oferta RTX A4000 **49633885**, tarifa total listada
**US$0.09037037037037038/h**, con 20 GB solicitados en la búsqueda; no es una reserva
ni una garantía de disponibilidad futura. Hay que reconsultar antes de alquilar.

`powershell-next-step.ps1` comprueba herramientas SSH y consulta A4000 disponibles
sin crear instancias. `setup_brake_gpu.sh` instala dependencias y Blender oficial
4.3.2 dentro de un contenedor Ubuntu/NVIDIA alquilado; comprueba el archivo
descargado contra los SHA-256 publicados por Blender. Su sintaxis se comprobó,
pero todavía no se ejecutó en una GPU remota. La disponibilidad y el controlador
del host deben verificarse antes de seleccionar imagen y comenzar el alquiler.

El apartado de configuración siguiente conserva la alternativa de operar desde
Codex; no es necesario para la ruta local de PowerShell elegida por el usuario.

## Acceso necesario

La clave se configura como secreto personal **VAST_API_KEY**, destinado únicamente
a **console.vast.ai**. No va en el chat, en archivos del repositorio, en argumentos
de consola, ni en el servidor GPU. El cliente local usa autenticación Bearer.

La propuesta sin valores está en `environment-requirements.json`. Al añadir un
requisito de secreto con ese destino, la configuración del entorno también debe
permitir el destino HTTPS. Conservar los permisos existentes y sus secretos.

El intento de guardar este requisito devolvió **draft_not_editable**; no quedó
guardado. Tras releer el borrador, se preserva aquí la propuesta y los archivos
para trasladarlos a un nuevo chat de configuración desde los ajustes del entorno.
No se publicó ni se modificó la configuración activa.

El endpoint se verificó en el
[cliente oficial de Vast.ai](https://github.com/vast-ai/vast-python):
`https://console.vast.ai/api/v0/bundles/`, operación POST de búsqueda de ofertas.
El SDK/CLI oficial admite `VAST_API_KEY` y autenticación `Authorization: Bearer`.

## Archivos incluidos en el ZIP

- `scene.blend`: escena autónoma, 720 fotogramas / 24 fps / 30 segundos;
  1080 × 1920, materiales procedurales y animación nativa. Es la copia previamente
  preparada para granja con denoising integrado de Blender.
- `render_brake_gpu.py`: ejecución en Blender GPU; prueba seis tomas por defecto.
  Selecciona una GPU NVIDIA con OptiX o CUDA y aborta si solo hay CPU. Usa
  Open Image Denoise integrado y PNG RGB/AgX. No necesita dependencias Python extra.
- `vast_brake_offers.py`: consulta de ofertas; no contiene operaciones de alquiler,
  arranque, parada o destrucción. `--dry-run` muestra la consulta sin usar clave/red.
- `budget.json`: límites de planificación y estado, sin precios inventados.
- `environment-requirements.json`: requisito de conexión, sin clave.

## Flujo previsto

1. Activar el secreto y el destino de red; comprobar readiness y autenticación.
2. Consultar ofertas de una GPU verificada con al menos 12 GB de VRAM y revisar
   GPU, tarifa total por hora, almacenamiento y cargos por transferencia. El
   filtro inicial de US$1/h no es un precio observado ni un límite total de gasto.
3. Elegir imagen/host, validar controlador y acceso a los resultados **antes** de
   iniciar el alquiler. Definir plazo de terminación en el controlador local y
   reserva para descarga. Esta automatización de alquiler/facturación todavía
   no está implementada ni probada: los scripts incluidos no controlan facturas.
4. Instalar/usar **Blender oficial 4.3.2** con Cycles, CUDA/OptiX y OIDN. La copia
   del paquete no requiere acceso a la API de Vast desde el servidor alquilado.
5. Renderizar las seis imágenes de prueba, observar aspecto, tiempos y bytes.
   Calcular coste completo con margen. Renderizar los 720 fotogramas solo si la
   proyección entra en US$10; el presupuesto ya está autorizado, no se necesita
   repetir la aprobación para un trabajo que quepa dentro de ese límite.
6. Descargar imágenes y manifiestos; comprobar hashes y cantidad de fotogramas.
   Después terminar/eliminar el alquiler por API y comprobar su estado/facturación.
   Detener solo Blender no detiene el alquiler y parar una VM puede dejar disco
   facturable. Conservar resultados locales antes de eliminar almacenamiento.
7. Montar aquí el Short con narración, flechas, textos y música. No publicar.

## Comandos del paquete

Consulta local sin conexión:

```bash
python vast_brake_offers.py --dry-run
```

Consulta autenticada, una vez configurado el secreto:

```bash
python vast_brake_offers.py
```

En la instancia GPU, usando su ruta real al Blender oficial:

```bash
blender -b scene.blend --python-exit-code 1 -P render_brake_gpu.py -- \
  --output /workspace/brake/benchmark --max-seconds 900
```

Después del cálculo de coste y con el controlador de facturación activo:

```bash
blender -b scene.blend --python-exit-code 1 -P render_brake_gpu.py -- \
  --full --output /workspace/brake/frames --max-seconds 3600
```

El límite de segundos se revisa entre fotogramas. No limita el coste de la cuenta,
no incluye preparación/transferencias y no termina la instancia. El informe de
prueba estima horas de render usando el peor fotograma × 720 × 1.5; no reemplaza
la comprobación de coste y plazo reales. El cliente de control deberá poder
terminar el alquiler independientemente del proceso de render.

## Verificación realizada aquí

Se comprobó sintaxis, consulta en seco, perfil del `.blend` y aborto sin GPU. No
se probó un render GPU ni la autenticación porque falta el acceso a Vast en este
entorno. El ZIP conserva los archivos necesarios aunque se cambie de entorno.
