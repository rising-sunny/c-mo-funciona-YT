# Prueba GPU en Vast.ai desde Windows PowerShell

`start-vast-benchmark.ps1` hace una prueba de seis fotogramas, descarga y verifica
los PNG y solicita la eliminacion de la instancia. No renderiza todavia el Short
completo. Conserva el PC encendido y conectado hasta ver **INSTANCIA ELIMINADA**.

## Que hace

1. Comprueba SSH/SCP, archivos y `VAST_API_KEY` en la sesion local.
2. Busca una A4000 verificada: una GPU de 16 GB, al menos 4 nucleos y 16 GB de
   RAM, CUDA >= 12.2, 20 GB de disco y tarifa total <= US$0.15/h. Usa la imagen
   oficial `nvidia/cuda:12.2.2-runtime-ubuntu22.04`, comprobada en Docker Hub.
3. Rechaza ofertas con costes de transferencia desconocidos o superiores a
   US$0.10/GB. Reserva coste de 45 minutos, 10 GB de entrada, 2 GB de salida y
   US$0.50 de margen; suma intentos anteriores del mismo directorio y mantiene
   US$2 de reserva global dentro del presupuesto autorizado de **US$10**.
   Es una estimacion conservadora, no una factura ni un limite en la cuenta Vast.
4. Genera una clave SSH exclusiva para esta prueba en el PC. Solo envia la parte
   publica a la nueva instancia; la API key nunca se envia al servidor GPU.
5. Crea una sola instancia, instala Blender oficial 4.3.2 y comprueba el archivo
   con los SHA-256 publicados por Blender. Renderiza seis tomas con Cycles GPU,
   1080 x 1920, hasta 96 muestras y denoising integrado.
6. Descarga `benchmark-results.zip`, comprueba su SHA-256, extrae y comprueba cada
   PNG contra el informe. Copia tambien `job.log` cuando la conexion lo permite.
7. Solicita eliminar SOLO la instancia identificada por el ID y la etiqueta
   unica de este trabajo, incluso ante errores. Comprueba su desaparicion y
   muestra **INSTANCIA ELIMINADA**. Nunca trata "offline" como "eliminada".

## Control local y resultados

El controlador usa `try/finally` para la limpieza. Un segundo proceso local
vigila el plazo de **45 minutos**, evita la suspension automatica del PC y
reintenta eliminar esa instancia si el proceso principal falla. Este proceso
depende del PC y de su conexion: no equivale a un corte de facturacion gestionado
por Vast y no funciona mientras el PC esta apagado. Si aparece **LIMPIEZA NO
CONFIRMADA**, revisa inmediatamente el ID indicado en la consola de Vast.

Si falla la descarga, el controlador prioriza cerrar el alquiler. Se pueden
perder imagenes de prueba aun no descargadas; la escena original sigue en el PC
y las imagenes son regenerables. No se modifica ninguna otra instancia.

Los resultados quedan en `jobs/<fecha-identificador>/benchmark/`, junto a
`lease.json` y registros. No contienen la API key. El informe guarda GPU,
backend, tiempos, tamanos y hashes. El primer fotograma puede incluir compilacion
de shaders; revisar los tiempos por toma antes de extrapolar el render completo.

## Ejecutar

Con `VAST_API_KEY` cargada en esa ventana:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\start-vast-benchmark.ps1
```

Para ver el plan sin red ni alquiler:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\start-vast-benchmark.ps1 -DryRun
```

Se comprobaron sintaxis y simulaciones offline: costes desconocidos/altos,
recovery tras creacion incierta, rechazo de creacion, error despues de crear la
instancia, eliminacion por etiqueta, estados offline y argumentos nativos con
espacios/comillas. No se han ejecutado aun alquileres o renders reales en Vast.

El paquete solo contiene la escena, scripts, instrucciones y requisitos sin
valores de secretos. Las herramientas y entorno locales de desarrollo no se
incluyen. No publica el video ni modifica la rama principal del repositorio.
