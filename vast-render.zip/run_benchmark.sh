#!/usr/bin/env bash
set -euo pipefail
cd /workspace/brake
trap 'printf failed > job.state' ERR
printf running > job.state
timeout --signal=TERM --kill-after=30s 15m bash setup_brake_gpu.sh
timeout --signal=TERM --kill-after=30s 20m \
  blender-4.3.2-linux-x64/blender -b scene.blend --python-exit-code 1 \
  -P render_brake_gpu.py -- --output benchmark --max-seconds 900
python3 - <<'PY'
import hashlib,json,zipfile
from pathlib import Path
report=json.loads(Path('benchmark/render-report.json').read_text())
assert len(report['frames'])==6
archive=Path('benchmark-results.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_STORED) as z:
    for p in sorted(Path('benchmark').iterdir()):
        if p.is_file():z.write(p,p.as_posix())
receipt=dict(sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
Path('benchmark-results.json').write_text(json.dumps(receipt)+'\n')
PY
printf done > job.state
