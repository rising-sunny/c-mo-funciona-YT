import json
from pathlib import Path
root=Path('/workspace/brake')
state=(root/'job.state').read_text().strip() if (root/'job.state').exists() else 'starting'
progress=json.loads((root/'benchmark/progress.json').read_text()) if (root/'benchmark/progress.json').exists() else {}
print(json.dumps({'state':state,'complete':progress.get('complete',0),'total':6}))
