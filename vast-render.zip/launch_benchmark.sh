#!/usr/bin/env bash
set -euo pipefail
cd /workspace/brake
printf starting > job.state
nohup bash run_benchmark.sh > job.log 2>&1 < /dev/null &
printf '%s\n' "$!" > job.pid
