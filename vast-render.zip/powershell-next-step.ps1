# Read-only checks in the user's current PowerShell session. No rental creation.
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:VAST_API_KEY)) {
    throw 'VAST_API_KEY is not loaded in this PowerShell window.'
}
Write-Host 'SSH tools:'
Get-Command ssh.exe, scp.exe, ssh-keygen.exe -ErrorAction SilentlyContinue |
    Select-Object Name, Source | Format-Table -AutoSize
$vastQuery = @'
{
  "verified": {"eq": true},
  "rentable": {"eq": true},
  "rented": {"eq": false},
  "num_gpus": {"eq": 1},
  "gpu_name": {"eq": "RTX A4000"},
  "gpu_ram": {"gte": 12000},
  "reliability2": {"gte": 0.98},
  "dph_total": {"lte": 0.15},
  "type": "on-demand", "allocated_storage": 20,
  "limit": 3, "order": [["dph_total", "asc"]]
}
'@
try {
    $vastNextOffers = Invoke-RestMethod -Method Post `
        -Uri 'https://console.vast.ai/api/v0/bundles/' `
        -Headers @{ Authorization = "Bearer $env:VAST_API_KEY" } `
        -ContentType 'application/json' -Body $vastQuery `
        -MaximumRedirection 0 -TimeoutSec 30 -ErrorAction Stop
    $vastNextOffers.offers | Select-Object id, gpu_name, gpu_ram, cuda_max_good, `
        cpu_ram, cpu_cores_effective, disk_bw, dph_total, storage_cost, `
        inet_up_cost, inet_down_cost | ConvertTo-Json -Depth 3
} catch {
    if ($_.Exception.Response) {Write-Host 'HTTP:' ([int]$_.Exception.Response.StatusCode)}
    if ($_.ErrorDetails.Message) {
        Write-Host $_.ErrorDetails.Message.Replace($env:VAST_API_KEY, '[OCULTA]')
    }
    throw 'Read-only Vast offer check failed. No rental was created.'
}
