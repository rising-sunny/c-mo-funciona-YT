param([switch]$DryRun)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'vast_common.ps1')

function Invoke-VastBenchmark {
    param([string]$Project=$PSScriptRoot,[switch]$DryRun)
    $query=@{verified=@{eq=$true};external=@{eq=$false};rentable=@{eq=$true};rented=@{eq=$false};
        num_gpus=@{eq=1};gpu_name=@{eq='RTX A4000'};gpu_ram=@{gte=16000};cuda_max_good=@{gte=12.2};
        cpu_ram=@{gte=16000};cpu_cores_effective=@{gte=4};reliability2=@{gte=0.98};dph_total=@{lte=0.15};
        type='on-demand';allocated_storage=20;limit=10;order=@(@('dph_total','asc'),@('cpu_cores_effective','desc'))}
    if ($DryRun) { return @{search=$query;image='nvidia/cuda:12.2.2-runtime-ubuntu22.04';frames=6;deadline_minutes=45;maximum_total_usd=10} | ConvertTo-Json -Depth 10 }
    if ([string]::IsNullOrWhiteSpace($env:VAST_API_KEY)) { throw 'Load VAST_API_KEY in this PowerShell session first.' }
    [Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    foreach ($tool in @('ssh.exe','scp.exe','ssh-keygen.exe','powershell.exe')) { $null=Get-Command $tool -ErrorAction Stop }
    $upload=@('scene.blend','render_brake_gpu.py','setup_brake_gpu.sh','run_benchmark.sh','launch_benchmark.sh','read_progress.py')
    foreach ($name in ($upload+@('vast_watchdog.ps1','vast_common.ps1'))) { if (!(Test-Path -LiteralPath (Join-Path $Project $name))) { throw "Missing $name" } }
    $offers=(Invoke-VastApi POST '/api/v0/bundles/' $query).offers
    $offer=@($offers | Where-Object {[int]$_.num_gpus -eq 1 -and [double]$_.cuda_max_good -ge 12.2 -and [double]$_.cpu_cores_effective -ge 4}) | Select-Object -First 1
    if (!$offer) { throw 'No suitable A4000 offer <= 0.15 USD/h. No rental created.' }
    $reservation=Get-VastReservation $offer
    $jobs=Join-Path $Project 'jobs'; New-Item -ItemType Directory -Path $jobs -Force | Out-Null
    $spent=0.0
    foreach ($file in @(Get-ChildItem -Path $jobs -Filter lease.json -Recurse -File)) {
        $previous=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
        if ($previous.creation_attempted -and !$previous.cleanup_confirmed) { throw ('Previous rental cleanup is pending: '+$previous.label) }
        if ($previous.creation_attempted) { $spent += [double]$previous.reserved_usd }
    }
    if ($spent+$reservation+2 -gt 10) { throw 'Budget reservation plus global reserve would exceed 10 USD.' }
    $job=Join-Path $jobs ([DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $job | Out-Null
    $key=Join-Path $job 'ssh-key'; $hosts=Join-Path $job 'known_hosts'
    $r=Invoke-VastNative 'ssh-keygen.exe' @('-q','-t','ed25519','-N','','-f',$key) 30
    if ($r.Code -ne 0) { throw ('SSH key creation failed: '+$r.Err) }
    $publicKey=(Get-Content -LiteralPath ($key+'.pub') -Raw).Trim()
    if (!$publicKey.StartsWith('ssh-ed25519 ')) { throw 'SSH public key validation failed.' }
    $label='physics-brake-'+[guid]::NewGuid().ToString('N')
    $state=@{label=$label;instance_id=$null;creation_attempted=$false;cleanup_confirmed=$false;
        deadline_utc=[DateTime]::UtcNow.AddMinutes(45).ToString('o');reserved_usd=$reservation;offer_id=[long]$offer.id;finished_utc=$null}
    $statePath=Join-Path $job 'lease.json'; Save-VastState $statePath $state
    $wdArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Project 'vast_watchdog.ps1'),'-StatePath',$statePath)
    $wd=Start-Process -FilePath 'powershell.exe' -ArgumentList (($wdArgs | ForEach-Object {Quote-VastNativeArg $_}) -join ' ') -WindowStyle Hidden -RedirectStandardError (Join-Path $job 'watchdog-start.log') -PassThru
    if ($wd.WaitForExit(2000)) { throw ('Watchdog did not start. No rental created. See '+(Join-Path $job 'watchdog-start.log')) }
    $state.watchdog_pid=$wd.Id; Save-VastState $statePath $state
    $report=$null; $connection=$null; $scpArgs=$null
    Write-Host ('OFERTA: '+$offer.gpu_name+' | USD/h '+$offer.dph_total+' | limite 45 minutos')
    Write-Host 'Comienza el alquiler. Mantiene el PC encendido y conectado hasta INSTANCIA ELIMINADA.'
    try {
        $state.creation_attempted=$true; Save-VastState $statePath $state
        try {
            $created=Invoke-VastApi PUT ("/api/v0/asks/"+$offer.id+'/') @{client_id='me';image='nvidia/cuda:12.2.2-runtime-ubuntu22.04';
                disk=20;runtype='ssh_direc ssh_proxy';label=$label;onstart='';env=@{};cancel_unavail=$true}
        } catch {
            if ($_.Exception.Message -match '^Vast HTTP (400|401|402|403|404|409|422) ') {
                $state.creation_attempted=$false; Save-VastState $statePath $state
            }
            throw
        }
        if ($created.new_contract) { $state.instance_id=[long]$created.new_contract; Save-VastState $statePath $state }
        if (!$created.success -or !$created.new_contract) {
            if (!$created.new_contract) { $state.creation_attempted=$false; Save-VastState $statePath $state }
            throw ('Vast did not confirm creation: '+$created.msg)
        }
        Write-Host ('INSTANCIA: '+$state.instance_id)
        $null=Invoke-VastApi POST ("/api/v0/instances/"+$state.instance_id+'/ssh/') @{ssh_key=$publicKey}
        $connection=$null; $sshOptions=@('-i',$key,'-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=accept-new','-o',('UserKnownHostsFile='+$hosts),'-o','ConnectTimeout=10','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2')
        $readyUntil=[DateTime]::UtcNow.AddMinutes(12)
        while ([DateTime]::UtcNow -lt $readyUntil) {
            $lease=Get-VastLease $state.instance_id
            if (!$lease -or $lease.label -ne $label) { throw 'Unexpected instance identity.' }
            if ($null -ne $lease.dph_total -and [double]$lease.dph_total -gt 0.15) { throw 'Actual hourly price exceeds the cap.' }
            $connection=Get-VastSsh $lease
            if ($lease.actual_status -eq 'running' -and $connection) {
                $sshArgs=@('-p',[string]$connection.Port)+$sshOptions+@(('root@'+$connection.Address),'echo VAST_SSH_READY')
                $r=Invoke-VastNative 'ssh.exe' $sshArgs 20
                if ($r.Code -eq 0 -and $r.Out.Contains('VAST_SSH_READY')) { break }
            }
            Write-Host ('Preparando maquina: '+$lease.actual_status); Start-Sleep -Seconds 10
            $connection=$null
        }
        if (!$connection) { throw 'SSH did not become ready within 12 minutes.' }
        $sshArgs=@('-p',[string]$connection.Port)+$sshOptions+@(('root@'+$connection.Address))
        $scpArgs=@('-P',[string]$connection.Port)+$sshOptions
        $r=Invoke-VastNative 'ssh.exe' ($sshArgs+@('mkdir -p /workspace/brake')) 30
        if ($r.Code -ne 0) { throw ('Remote directory creation failed: '+$r.Err) }
        $paths=@($upload | ForEach-Object {Join-Path $Project $_})
        $r=Invoke-VastNative 'scp.exe' ($scpArgs+@('-C')+$paths+@(('root@'+$connection.Address+':/workspace/brake/'))) 180
        if ($r.Code -ne 0) { throw ('Upload failed: '+$r.Err) }
        $r=Invoke-VastNative 'ssh.exe' ($sshArgs+@('bash /workspace/brake/launch_benchmark.sh')) 30
        if ($r.Code -ne 0) { throw ('Job launch failed: '+$r.Err) }
        $done=$false
        while ([DateTime]::UtcNow -lt [DateTime]::Parse($state.deadline_utc).ToUniversalTime().AddMinutes(-3)) {
            Start-Sleep -Seconds 15
            $r=Invoke-VastNative 'ssh.exe' ($sshArgs+@('python3 /workspace/brake/read_progress.py')) 30
            if ($r.Code -ne 0) { Write-Host 'Esperando conexion/progreso...'; continue }
            try { $progress=$r.Out | ConvertFrom-Json } catch { continue }
            Write-Host ('Render: '+$progress.complete+'/6 | '+$progress.state)
            if ($progress.state -eq 'failed') { throw 'Remote render failed; fetching job.log before cleanup.' }
            if ($progress.state -eq 'done') { $done=$true; break }
        }
        if (!$done) { throw 'Benchmark deadline reached.' }
        foreach ($name in @('benchmark-results.zip','benchmark-results.json')) {
            $r=Invoke-VastNative 'scp.exe' ($scpArgs+@(('root@'+$connection.Address+':/workspace/brake/'+$name),(Join-Path $job $name))) 120
            if ($r.Code -ne 0) { throw ('Download failed: '+$r.Err) }
        }
        $receipt=Get-Content -LiteralPath (Join-Path $job 'benchmark-results.json') -Raw | ConvertFrom-Json
        $archive=Join-Path $job 'benchmark-results.zip'
        if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $receipt.sha256) { throw 'Downloaded ZIP hash mismatch.' }
        Expand-Archive -LiteralPath $archive -DestinationPath $job -Force
        $report=Get-Content -LiteralPath (Join-Path $job 'benchmark/render-report.json') -Raw | ConvertFrom-Json
        if (@($report.frames).Count -ne 6) { throw 'Expected six benchmark frames.' }
        foreach ($frame in $report.frames) {
            $png=Join-Path $job ('benchmark/{0:D4}.png' -f [int]$frame.frame)
            if ((Get-FileHash -LiteralPath $png -Algorithm SHA256).Hash -ne $frame.sha256) { throw 'PNG integrity check failed.' }
        }
        Write-Host ('RESULTADOS VERIFICADOS: '+(Join-Path $job 'benchmark'))
    } finally {
        if ($connection -and $scpArgs) {
            try { $null=Invoke-VastNative 'scp.exe' ($scpArgs+@(('root@'+$connection.Address+':/workspace/brake/job.log'),(Join-Path $job 'job.log'))) 30 } catch {}
        }
        try { Complete-VastCleanup $state $statePath }
        catch { Write-Warning ('LIMPIEZA NO CONFIRMADA: '+$_.Exception.Message+' | Etiqueta: '+$label+' | Estado local: '+$statePath); throw }
    }
    if ($report) {
        [pscustomobject]@{gpu=$report.profile.gpu;backend=$report.profile.backend;frames=6;
            seconds=$report.elapsed_seconds;conservative_full_render_hours=$report.conservative_render_hours;
            results=(Join-Path $job 'benchmark');instance_deleted=$state.cleanup_confirmed} | ConvertTo-Json -Depth 4
    }
}

if ($MyInvocation.InvocationName -ne '.') { Invoke-VastBenchmark -Project $PSScriptRoot -DryRun:$DryRun }
