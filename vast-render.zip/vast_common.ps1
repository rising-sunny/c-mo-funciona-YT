# Common functions. Loading this file does not contact Vast or create resources.
function Invoke-VastApi {
    param([string]$Method, [string]$Path, $Body = $null)
    if ([string]::IsNullOrWhiteSpace($env:VAST_API_KEY)) { throw 'VAST_API_KEY is missing.' }
    if (!$Path.StartsWith('/api/')) { throw 'Invalid API path.' }
    $params = @{ Method=$Method; Uri=('https://console.vast.ai'+$Path);
        Headers=@{Authorization=('Bearer '+$env:VAST_API_KEY.Trim())};
        MaximumRedirection=0; TimeoutSec=30; ErrorAction='Stop' }
    if ($null -ne $Body) { $params.ContentType='application/json'; $params.Body=($Body | ConvertTo-Json -Depth 15 -Compress) }
    try { return Invoke-RestMethod @params }
    catch {
        $code=0
        if ($_.Exception.Response) { $code=[int]$_.Exception.Response.StatusCode }
        if ($Method -in @('GET','DELETE') -and $code -eq 404) { return $null }
        $detail=$_.ErrorDetails.Message
        if (!$detail) { $detail=$_.Exception.Message }
        $detail=$detail.Replace($env:VAST_API_KEY.Trim(),'[REDACTED]')
        throw "Vast HTTP $code ($Method $Path): $detail"
    }
}

function Get-VastLease {
    param([long]$Id)
    $r=Invoke-VastApi GET "/api/v0/instances/$Id/?owner=me"
    if (!$r) { return $null }
    return $r.instances
}

function Find-VastLeaseByLabel {
    param([string]$Label)
    $after=''
    for ($page=0; $page -lt 40; $page++) {
        $path='/api/v1/instances/?limit=25&select_filters=%7B%7D&order_by=%5B%7B%22col%22%3A%22id%22%2C%22dir%22%3A%22asc%22%7D%5D'
        if ($after) { $path+='&after_token='+[uri]::EscapeDataString($after) }
        $r=Invoke-VastApi GET $path
        $matches=@($r.instances | Where-Object { $_.label -eq $Label })
        if ($matches.Count -gt 1) { throw 'Unexpected duplicate lease label. Inspect Vast before continuing.' }
        if ($matches.Count -eq 1) { return $matches[0] }
        $after=$r.next_token
        if (!$after) { return $null }
    }
    throw 'Could not complete instance recovery lookup.'
}

function Remove-VastLease {
    param([long]$Id,[string]$Label)
    for ($attempt=0; $attempt -lt 3; $attempt++) {
        $lease=Get-VastLease $Id
        if ($lease -and $lease.actual_status -eq 'destroyed') { return $true }
        if ($lease -and $lease.label -ne $Label) { throw 'Cleanup refused: instance label differs.' }
        $r=Invoke-VastApi DELETE "/api/v0/instances/$Id/" @{}
        if ($null -eq $r) { return $true }
        if ($r.success -eq $false) { throw 'Vast refused instance deletion.' }
        for ($poll=0; $poll -lt 10; $poll++) {
            Start-Sleep -Seconds 3
            $lease=Get-VastLease $Id
            if (!$lease -or $lease.actual_status -eq 'destroyed') { return $true }
        }
    }
    throw "Deletion of $Id is not confirmed. Check the Vast console immediately."
}

function Get-VastReservation {
    param($Offer,[double]$Minutes=45)
    foreach ($field in @('dph_total','inet_up_cost','inet_down_cost','storage_cost')) {
        if ($null -eq $Offer.$field -or [double]$Offer.$field -lt 0) { throw "Missing/invalid cost: $field" }
    }
    if ([double]$Offer.dph_total -gt 0.15) { throw 'Hourly rate exceeds 0.15 USD.' }
    if ([double]$Offer.inet_up_cost -gt 0.1 -or [double]$Offer.inet_down_cost -gt 0.1) { throw 'Transfer rates exceed the search policy.' }
    # dph_total already includes the 20 GB allocated_storage search setting.
    return [math]::Round(([double]$Offer.dph_total*$Minutes/60 + 10*[double]$Offer.inet_down_cost + 2*[double]$Offer.inet_up_cost + 0.5),4)
}

function Save-VastState {
    param([string]$Path,$State)
    if (Test-Path -LiteralPath $Path) {
        try { $old=Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json; if ($old.cleanup_confirmed) { $State.cleanup_confirmed=$true } } catch {}
    }
    $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    [IO.File]::WriteAllText($temp,($State | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temp -Destination $Path -Force
}

function Complete-VastCleanup {
    param($State,[string]$StatePath)
    if (!$State.creation_attempted) { $State.cleanup_confirmed=$true; Save-VastState $StatePath $State; return }
    if (!$State.instance_id) {
        $found=Find-VastLeaseByLabel $State.label
        if (!$found) { throw 'Creation outcome is uncertain; the independent watchdog will check this label again. Do not start another rental.' }
        $State.instance_id=[long]$found.id; Save-VastState $StatePath $State
    }
    $null=Remove-VastLease $State.instance_id $State.label
    $State.cleanup_confirmed=$true; $State.finished_utc=[DateTime]::UtcNow.ToString('o')
    Save-VastState $StatePath $State
    Write-Host ('INSTANCIA ELIMINADA: '+$State.instance_id)
}

function Quote-VastNativeArg {
    param([AllowEmptyString()][string]$Value)
    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') { return $Value }
    $escaped=[regex]::Replace($Value,'(\\*)"','$1$1\"')
    $escaped=[regex]::Replace($escaped,'(\\+)$','$1$1')
    return '"'+$escaped+'"'
}

function Invoke-VastNative {
    param([string]$Exe,[string[]]$Arguments,[int]$Seconds=60)
    $si=[Diagnostics.ProcessStartInfo]::new(); $si.FileName=$Exe
    $si.Arguments=(($Arguments | ForEach-Object { Quote-VastNativeArg $_ }) -join ' ')
    $si.UseShellExecute=$false; $si.CreateNoWindow=$true; $si.RedirectStandardOutput=$true; $si.RedirectStandardError=$true
    $process=[Diagnostics.Process]::new(); $process.StartInfo=$si
    try {
        $null=$process.Start(); $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        if (!$process.WaitForExit($Seconds*1000)) { $process.Kill(); throw "Command timed out: $Exe" }
        $process.WaitForExit()
        return [pscustomobject]@{Code=$process.ExitCode; Out=$stdout.Result; Err=$stderr.Result}
    } finally { $process.Dispose() }
}

function Get-VastSsh {
    param($Lease)
    $port22=$Lease.ports.'22/tcp'
    if ($port22) { $address=$Lease.public_ipaddr; $port=[int]$port22[0].HostPort }
    else { $address=$Lease.ssh_host; $port=[int]$Lease.ssh_port }
    if (!$address -or $address -notmatch '^[A-Za-z0-9.-]+$' -or $port -lt 1 -or $port -gt 65535) { return $null }
    return [pscustomobject]@{Address=$address; Port=$port}
}
