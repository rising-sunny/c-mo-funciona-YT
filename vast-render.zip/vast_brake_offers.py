"""Read-only Vast.ai offer search. Never create, start, stop or destroy instances."""
import argparse,json,os,sys,urllib.error,urllib.request

ENDPOINT='https://console.vast.ai/api/v0/bundles/'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dry-run',action='store_true');p.add_argument('--max-hourly',type=float,default=1.)
    a=p.parse_args()
    if not 0<a.max_hourly<=2:raise SystemExit('Choose a positive hourly search cap <= 2 USD; this cap is not a total-spend guarantee.')
    query={'verified':{'eq':True},'external':{'eq':False},'rentable':{'eq':True},'rented':{'eq':False},
           'num_gpus':{'eq':1},'gpu_ram':{'gte':12000},'reliability2':{'gte':.98},'dph_total':{'lte':a.max_hourly},
           'type':'on-demand','allocated_storage':20,'order':[['dph_total','asc']],'limit':15}
    if a.dry_run:
        print(json.dumps({'endpoint':ENDPOINT,'operation':'offer search only','query':query,'total_budget_usd':10,
                          'note':'Hourly search cap is not a spending limit. Benchmark and all storage/transfer charges must be checked before rental.'},indent=2));return
    key=os.environ.get('VAST_API_KEY')
    if not key:raise SystemExit('VAST_API_KEY is not configured. Add it through secure environment settings, not a command-line argument.')
    request=urllib.request.Request(ENDPOINT,data=json.dumps(query).encode(),method='POST',
        headers={'Authorization':'Bearer '+key,'Content-Type':'application/json','Accept':'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect()).open(request,timeout=30) as response:result=json.load(response)
    except urllib.error.HTTPError as e:raise SystemExit(f'Vast.ai request failed: HTTP {e.code}. No rental was requested.')
    except urllib.error.URLError:raise SystemExit('Vast.ai network request failed. No rental was requested.')
    fields=('id','gpu_name','num_gpus','gpu_ram','dph_total','storage_cost','inet_up_cost','inet_down_cost','reliability2','geolocation','dlperf')
    rows=[{k:r.get(k) for k in fields} for r in result.get('offers',[])]
    print(json.dumps({'offers':rows,'rental_created':False},indent=2))

if __name__=='__main__':main()
