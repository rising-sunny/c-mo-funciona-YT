param([Parameter(Mandatory=$true)][string]$StatePath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'vast_common.ps1')
[Net.ServicePointManager]::SecurityProtocol=[Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
try {
    Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class VastWatchPower { [DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint flags); }'
    $null=[VastWatchPower]::SetThreadExecutionState(2147483649)
    while ($true) {
        $state=Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
        if ($state.cleanup_confirmed) { exit 0 }
        if ([DateTime]::UtcNow -ge [DateTime]::Parse($state.deadline_utc).ToUniversalTime()) { break }
        Start-Sleep -Seconds 10
    }
    for ($attempt=0; $attempt -lt 40; $attempt++) {
        try {
            $state=Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
            if ($state.cleanup_confirmed) { exit 0 }
            Complete-VastCleanup $state $StatePath
            exit 0
        } catch {
            $message=($_.Exception.Message).Replace($env:VAST_API_KEY,'[REDACTED]')
            Add-Content -LiteralPath ($StatePath+'.watchdog.log') -Value $message
            Start-Sleep -Seconds 15
        }
    }
    throw 'Watchdog could not confirm removal. Check Vast console.'
} finally {
    try { $null=[VastWatchPower]::SetThreadExecutionState(2147483648) } catch {}
}
