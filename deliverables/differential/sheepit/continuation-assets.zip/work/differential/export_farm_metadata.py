"""Export camera projections only. Does not render or restart the cancelled render."""
import bpy,json
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
root=Path('/workspace/c-mo-funciona-YT');out=root/'work/differential/farm-metadata';out.mkdir(exist_ok=True)
s=bpy.context.scene
for f in range(1,1153):
 s.frame_set(f);pts={}
 for k,v in {'left':(-.36,0,0),'right':(.36,0,0),'carrier':(0,.078,0),'spider':(0,0,.06),'input':(-.15,.135,0)}.items():
  v=Vector(v)
  if k in ('carrier','spider'):v=bpy.data.objects['Carrier and crown: common rigid body'].matrix_world@v
  p=world_to_camera_view(s,s.camera,v);pts[k]=[p.x*1080,(1-p.y)*1920]
 (out/f'{f:04d}.json').write_text(json.dumps({'source':'projection_only_for_sheepit','points':pts}))
print('Exported 1152 projection metadata files; no render performed.')
