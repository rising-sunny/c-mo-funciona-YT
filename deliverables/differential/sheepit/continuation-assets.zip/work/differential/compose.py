"""Native frame overlays, aligned English captions, original score, verified encode."""
import json,math,subprocess,hashlib,textwrap,re
from pathlib import Path
import numpy as np
import soundfile as sf
from PIL import Image,ImageDraw,ImageFont
ROOT=Path('/workspace/c-mo-funciona-YT');work=ROOT/'work/differential';out=ROOT/'output/differential';frames=work/'frames'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(s,b=False):return ImageFont.truetype(BOLD if b else FONT,s)
WHITE='#e5edf7';MUTED='#a6b8cd';CYAN='#52dfdf';ORANGE='#ffb765'
cues=json.loads((out/'audio/narration.json').read_text())['cues']
inspection_anchors=json.loads((out/'inspection-anchors.json').read_text())
def text(d,xy,s,size=34,color=WHITE,b=False,anchor=None):d.text(xy,s,font=font(size,b),fill=color,anchor=anchor,stroke_width=0)
def centered(d,y,s,size=36,color=WHITE,b=False):text(d,(540,y),s,size,color,b,'mt')
def arrow(d,a,b,color,width=5):
 d.line([a,b],fill=color,width=width);v=np.array(b)-a;v=v/(np.linalg.norm(v)+1e-10);p=np.array([-v[1],v[0]])
 d.polygon([tuple(b),tuple(np.array(b)-v*18+p*9),tuple(np.array(b)-v*18-p*9)],fill=color)
def curved_arrow(d,x,y,rx,ry,color,width=5):
 points=[(x+rx*math.cos(a),y+ry*math.sin(a)) for a in np.linspace(math.radians(310),math.radians(30),40)]
 d.line(points,fill=color,width=width);arrow(d,points[-3],points[-1],color,width)
def overlay(f,im,pts):
 t=(f-1)/24;im=im.convert('RGBA');layer=Image.new('RGBA',im.size);d=ImageDraw.Draw(layer)
 d.rectangle((0,0,1080,270),fill=(5,11,20,225));d.rounded_rectangle((50,1360,1030,1645),radius=20,fill=(5,11,20,230))
 text(d,(64,62),'THE PHYSICS WITHIN',25,CYAN,True)
 step=0 if t<6 else 1 if t<13 else 2 if t<21 else 3 if t<29 else 4 if t<36 else 5 if t<42 else 6
 titles=['ONE ENGINE. TWO SPEEDS.','INSIDE AN OPEN DIFFERENTIAL','STRAIGHT → CORNER','ORBITING + SPINNING','THE SPEED BALANCE','PAUSE & PREDICT','SAME TORQUE. MORE POWER.']
 text(d,(64,120),titles[step],39,WHITE,True)
 text(d,(64,192),'Generic transverse drive • inspection cut • slow motion',25,MUTED)
 if t<6:
  centered(d,1400,'Why not lock both wheels together?',36,WHITE,True)
  centered(d,1470,'A corner demands two different speeds.',31,MUTED)
  centered(d,1540,'Equal wheel radii · rolling without slip',26,MUTED)
 elif t<13:
  arrow(d,(760,480),pts['carrier'],CYAN);text(d,(590,425),'CARRIER + CROWN',26,CYAN,True)
  arrow(d,(230,590),inspection_anchors['input_pinion'],ORANGE);text(d,(65,535),'INPUT PINION',25,ORANGE,True)
  centered(d,1400,'48 crown teeth / 12 pinion teeth',35,WHITE,True)
  centered(d,1470,'ωinput = −4 ωcarrier',42,ORANGE)
  centered(d,1550,'Minus sign: external gears turn oppositely.',26,MUTED)
 elif t<21:
  u=max(0,min(1,(t-15)/4));wl=.6-.24*u;wr=.6+.24*u
  if t<15:
   for x,col in ((330,CYAN),(750,ORANGE)):
    arrow(d,(x,510),(x,350),col);d.rounded_rectangle((x-25,500,x+25,580),8,fill=col)
   d.line((330,540,750,540),fill=WHITE,width=5);centered(d,615,'STRAIGHT: equal paths, equal speeds',27)
  else:
   for r,col in ((130,CYAN),(300,ORANGE)):
    d.arc((330-r,660-r,330+r,660+r),180,280,fill=col,width=6)
   a=math.radians(200+65*u)
   pos=[]
   for r,col in ((130,CYAN),(300,ORANGE)):
    p=(330+r*math.cos(a),660+r*math.sin(a));pos.append(p);d.ellipse((p[0]-12,p[1]-12,p[0]+12,p[1]+12),fill=col)
   d.line(pos,fill=WHITE,width=8);text(d,(680,390),'OUTER',28,ORANGE,True);text(d,(680,440),'Longer path',26,ORANGE);text(d,(680,535),'INNER',28,CYAN,True);text(d,(680,585),'Shorter path',26,CYAN)
  for k,v,col,label in [('left',wl,CYAN,'LEFT'),('right',wr,ORANGE,'RIGHT')]:
   x,y=pts[k];curved_arrow(d,x,y,36,50,col)
  centered(d,1400,f'ωL = {wl:.2f}       ωR = {wr:.2f} rad/s',38,WHITE,True)
  centered(d,1480,'ωcarrier = 0.60 rad/s',37,CYAN)
  centered(d,1555,'Wheel speed follows distance travelled.',27,MUTED)
 elif t<29:
  x,y=pts['spider'];arrow(d,(830,390),(x,y),ORANGE);text(d,(580,330),'SPIDER GEARS',30,ORANGE,True)
  centered(d,1400,'Straight: orbit, no relative spin.',33,WHITE,True)
  centered(d,1475,'Corner: orbit AND spin on the cross pin.',30,CYAN)
  centered(d,1550,'Spin is measured relative to the carrier.',26,MUTED)
 elif t<36:
  centered(d,365,'ωL + ωR = 2ωcarrier',53,CYAN,True)
  centered(d,455,'0.36 + 0.84 = 2 × 0.60 rad/s',35)
  for x,v,col in ((245,.36,CYAN),(710,.84,ORANGE)):
   d.rounded_rectangle((x,540,x+130,540+v*210),12,fill=col)
  centered(d,1400,'The carrier sets the average.',37,WHITE,True)
  centered(d,1475,'Left: −0.24     Right: +0.24 rad/s',33)
  centered(d,1550,'Equal side gears · kinematic relation',27,MUTED)
 elif t<42:
  centered(d,380,'FASTER WHEEL',53,ORANGE,True)
  centered(d,460,'MORE TORQUE?',58,WHITE,True)
  centered(d,1400,'Pause here and make your prediction.',33,WHITE,True)
  centered(d,1480,'A · More torque       B · Equal torque',32)
  centered(d,1550,'Consider an ideal open differential.',27,MUTED)
 else:
  centered(d,350,'TL = TR = 20 N·m',51,CYAN,True)
  centered(d,440,'Torque ON each output shaft',29,MUTED)
  for k,col in [('left',CYAN),('right',ORANGE)]:
   x,y=pts[k];curved_arrow(d,x,y,55,70,col,8)
  centered(d,1400,'P = Tω  →  7.2 W  /  16.8 W',40,WHITE,True)
  centered(d,1480,'Different speed. Equal torque.',35,CYAN,True)
  centered(d,1550,'Ideal · quasi-static · losses and inertia neglected',25,MUTED)
 # Word groups timed within each synthesized phrase; no caption crosses a shot.
 for a,b,s in cues:
  if a<=t<b:
   words=s.split();groups=[words[i:i+7] for i in range(0,len(words),7)];idx=min(len(groups)-1,int((t-a)/(b-a)*len(groups)))
   lines=textwrap.wrap(' '.join(groups[idx]),width=39)
   d.rounded_rectangle((50,1690,1030,1690+len(lines)*50+30),16,fill=(0,0,0,220))
   for j,line in enumerate(lines):centered(d,1705+j*50,line,38,WHITE,True)
   break
 text(d,(64,1850),'Angular-speed and torque arrows are schematic.',22,MUTED)
 return Image.alpha_composite(im,layer).convert('RGB')
def prepare_audio():
 def stamp(t):
  ms=round(t*1000);return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d},{ms%1000:03d}'
 captions=[]
 for a,b,s in cues:
  w=s.split();g=[w[i:i+7] for i in range(0,len(w),7)]
  for j,words in enumerate(g):captions.append((a+(b-a)*j/len(g),a+(b-a)*(j+1)/len(g),' '.join(words)))
 (out/'subtitles.srt').write_text('\n\n'.join(f'{i}\n{stamp(a)} --> {stamp(b)}\n{s}' for i,(a,b,s) in enumerate(captions,1))+'\n')
 rate=48000;time=np.arange(48*rate)/rate;rng=np.random.default_rng(117)
 gate=np.clip((time-5)/2,0,1)*np.clip((36-time)/2,0,1)
 sfx=.007*gate*(np.sin(2*np.pi*190*time)+.35*np.sin(2*np.pi*380*time))*(.75+.25*np.cos(2*np.pi*4.58*time))
 for start in (3,6):
  dt=np.maximum(time-start,0);sfx+=.018*np.exp(-dt*14)*(time>=start)*(np.sin(2*np.pi*670*dt)+rng.normal(0,.2,len(time)))
 sf.write(out/'audio/mechanical-effects.wav',sfx,rate)
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(out/'audio/narration.wav'),'-i',str(out/'audio/quiet-circuit-study.wav'),'-i',str(out/'audio/mechanical-effects.wav'),'-filter_complex','[1:a]volume=0.65[m];[0:a][m][2:a]amix=inputs=3:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=7[a]','-map','[a]','-ar','48000',str(out/'audio/mix.wav')],check=True)
def main():
 missing=[f for f in range(1,1153) if not (frames/f'{f:04d}.png').exists()]
 if missing:raise RuntimeError(f'{len(missing)} native frames still missing')
 prepare_audio()
 cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','24','-i','-','-i',str(out/'audio/mix.wav'),'-c:v','libx264','-preset','slow','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','48',str(out/'video.mp4')]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for f in range(1,1153):
  pts=json.loads((frames/f'{f:04d}.json').read_text())['points'];im=overlay(f,Image.open(frames/f'{f:04d}.png'),pts)
  if f==601:im.save(out/'poster.png')
  p.stdin.write(im.tobytes())
 p.stdin.close()
 if p.wait():raise RuntimeError('encode failed')
 subprocess.run(['ffmpeg','-v','error','-i',str(out/'video.mp4'),'-f','null','-'],check=True)
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out/'video.mp4')]))
 v=next(s for s in probe['streams'] if s['codec_type']=='video')
 assert (v['width'],v['height'],v['nb_frames'])==(1080,1920,'1152')
 assert v['r_frame_rate']=='24/1' and abs(float(probe['format']['duration'])-48)<.1
 measured=subprocess.run(['ffmpeg','-hide_banner','-i',str(out/'video.mp4'),'-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
 audio=json.loads(measured[measured.rfind('{'):measured.rfind('}')+1]);assert -17<float(audio['input_i'])<-15 and float(audio['input_tp'])<=-1
 (out/'final-validation.json').write_text(json.dumps({'status':'complete','ffprobe':probe,'audio_loudness':audio,'native_frames':1152,'interpolation':False},indent=2))
 (out/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  '+n for n in ['video.mp4','differential.blend'])+'\n')
if __name__=='__main__':main()
