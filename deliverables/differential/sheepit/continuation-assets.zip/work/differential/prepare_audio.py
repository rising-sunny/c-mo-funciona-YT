import sys,json
from pathlib import Path
import numpy as np
import soundfile as sf
ROOT=Path('/workspace/c-mo-funciona-YT');sys.path.insert(0,str(ROOT))
import narration
out=ROOT/'output/differential';work=ROOT/'work/differential'
segments=[
 (0,5.9,'Two wheels. One engine. How can both wheels turn at different speeds?'),
 (6,12.8,'An open differential splits the drive. The crown gear and carrier rotate together.'),
 (13,20.9,'Going straight, both wheels turn equally. In a corner, the outer wheel travels farther, so it turns faster.'),
 (21,28.8,'The spider gears now spin on their own axes, while still orbiting with the carrier.'),
 (29,35.8,'One side gains exactly the speed the other loses. Their average is the carrier speed.'),
 (36,41.2,'Pause. Does the faster wheel receive more torque?'),
 (42,47.8,'No. An ideal open differential delivers equal output torques. But the faster wheel receives more power.')]
c={'duration':48,'narration':{'engine':'kokoro','model':'models/kokoro-en-v0_19','voice':'Kokoro af_bella','speaker_id':1,'segments':[{'start':a,'end':b,'text':t} for a,b,t in segments]}}
(work/'narration-config.json').write_text(json.dumps(c,indent=2))
narration.load=lambda p:json.loads(p.read_text())
narration.generate(work/'narration-config.json',out/'audio')
# Original understated electronic ambience. No third-party samples or quotations.
rate=48000;t=np.arange(48*rate)/rate
music=np.zeros_like(t)
for j,base in enumerate([110,130.8128,97.9989,146.8324]):
 gate=np.maximum(0,np.sin(np.pi*np.clip((t-j*12)/12,0,1)))**2
 for k in [1,2,3]:music+=.032/k*np.sin(2*np.pi*base*k*t+.1*np.sin(.3*t))*gate
music*=np.minimum(t/2,1)*np.minimum((48-t)/3,1)
sf.write(out/'audio/quiet-circuit-study.wav',np.stack([music,np.roll(music,211)],axis=1),rate)
