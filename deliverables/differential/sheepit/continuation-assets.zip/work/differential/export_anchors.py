"""Export actual world-point calibration for the fixed overview camera."""
import bpy,json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from pathlib import Path
s=bpy.context.scene;s.frame_set(241)
p=Vector((-.085,.160,0));q=world_to_camera_view(s,s.camera,p)
Path('/workspace/c-mo-funciona-YT/output/differential/inspection-anchors.json').write_text(json.dumps({'world_point_m':list(p),'camera_frame':241,'input_pinion':[q.x*1080,(1-q.y)*1920]},indent=2))
