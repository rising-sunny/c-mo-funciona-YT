"""Generic open differential. All dimensions in metres; output axes X.
Bevel teeth use spherical involute approximations, not production gear cutting data.
"""
import bpy, bmesh, math, os, sys, json
from mathutils import Vector
from pathlib import Path
from bpy.app.handlers import persistent
OUT=Path('/workspace/c-mo-funciona-YT/output/differential')
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
def metal(name,color,rough):
 m=bpy.data.materials.new(name); m.use_nodes=True
 n=m.node_tree.nodes; l=m.node_tree.links; p=n.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*color,1); p.inputs['Metallic'].default_value=.93; p.inputs['Roughness'].default_value=rough
 tex=n.new('ShaderNodeTexNoise'); tex.inputs['Scale'].default_value=1900; tex.inputs['Detail'].default_value=2
 bump=n.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.16; bump.inputs['Distance'].default_value=.000035
 l.new(tex.outputs['Fac'],bump.inputs['Height']); l.new(bump.outputs['Normal'],p.inputs['Normal'])
 p.inputs['Coat Weight'].default_value=.18; p.inputs['Coat Roughness'].default_value=.15
 return m
steel=metal('Oil-wetted ground steel',(.34,.39,.44),.23)
iron=metal('Graphite cast iron',(.075,.09,.105),.48)
gold=metal('Warm inspection edge',(.36,.19,.055),.29)
dark=metal('Black oxide fasteners',(.045,.055,.065),.31)
rubber=bpy.data.materials.new('Satin carbon rubber');rubber.use_nodes=True;rubber.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.012,.016,.02,1);rubber.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.73
iron.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.028,.036,.045,1)
for node in iron.node_tree.nodes:
 if node.type=='BUMP':node.inputs['Distance'].default_value=.00028;node.inputs['Strength'].default_value=.5
def finish(o,name,mat,parent=None,bevel=.0005):
 o.name=name; o.data.materials.append(mat)
 if parent: o.parent=parent
 if bevel:
  b=o.modifiers.new('Machined edge radii','BEVEL'); b.width=bevel;b.segments=3
 for p in o.data.polygons:p.use_smooth=True
 return o
def empty(name,parent=None):
 o=bpy.data.objects.new(name,None);sc.collection.objects.link(o);o.parent=parent;return o
def cyl(name,r,depth,loc,mat=steel,parent=None,axis='X',vertices=64):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=loc)
 o=bpy.context.object
 if axis=='X':o.rotation_euler[1]=math.pi/2
 elif axis=='Y':o.rotation_euler[0]=math.pi/2
 return finish(o,name,mat,parent)
def ring(name,ri,ro,x,depth,mat,parent=None,start=0,end=2*math.pi,axis='X'):
 verts=[];faces=[];N=max(24,round(160*(end-start)/(2*math.pi)))
 for a in range(N+1):
  t=start+(end-start)*a/N
  for z,r in ((x-depth/2,ri),(x-depth/2,ro),(x+depth/2,ro),(x+depth/2,ri)):
   v=(z,r*math.cos(t),r*math.sin(t))
   if axis=='Z':v=(v[1],v[2],v[0])
   verts.append(v)
 for a in range(N):
  for j in range(4):faces.append((4*a+j,4*a+(j+1)%4,4*(a+1)+(j+1)%4,4*(a+1)+j))
 if end-start<2*math.pi-1e-6:faces.extend([(0,3,2,1),(4*N,4*N+1,4*N+2,4*N+3)])
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-8);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
 o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);finish(o,name,mat,parent)
 for p in me.polygons:p.use_smooth=abs(p.normal.x if axis=='X' else p.normal.z)<.8
 return o
carrier=empty('Carrier and crown: common rigid body')
left=empty('Left side gear and axle');right=empty('Right side gear and axle')
sat1=empty('Upper spider: spin relative to carrier',carrier);sat2=empty('Lower spider: spin relative to carrier',carrier)
def bevel_gear(name,z,delta,L0,L1,parent,direction=1,axis='X',phase=0):
 # Spherical involute evaluated at each cone distance; 20 degree pressure angle.
 # Common apex at origin. Side 24 teeth / spider 12 teeth, pitch cones complementary.
 sd=math.sin(delta);cd=math.cos(delta); alpha=math.radians(20)
 db=math.asin(sd*math.cos(alpha));module=2*sd/z
 root=delta-1.25*module;tip=delta+.8*module
 def inv(theta):
  if theta<=db:return 0
  s=math.acos(min(1,math.cos(theta)/math.cos(db)))
  return s/math.sin(db)-math.atan2(math.sin(s),math.sin(db)*math.cos(s))
 ip=inv(delta); points=[]
 for k in range(z):
  center=2*math.pi*k/z+phase
  # Local angular half thickness from virtual spur gear / cos(delta).
  for sign,rs in ((-1,[root,db,db+(tip-db)/3,db+2*(tip-db)/3,tip]),(1,[tip,db+2*(tip-db)/3,db+(tip-db)/3,db,root])):
   for r in rs:
    half=.92*math.pi/(2*z)+ip-inv(r)
    a=center+sign*half
    points.append((r,a))
 verts=[];N=len(points)
 for L in (L0,L1):
  for r,a in points:
   axial=direction*L*math.cos(r)
   v=(axial,L*math.sin(r)*math.cos(a),L*math.sin(r)*math.sin(a))
   if axis=='Z':v=(v[1],v[2],v[0])
   verts.append(v)
 for L in (L0,L1):
  for r,a in points:
   v=(direction*L*math.cos(root),L*math.sin(root)*math.cos(a),L*math.sin(root)*math.sin(a))
   if axis=='Z':v=(v[1],v[2],v[0])
   verts.append(v)
 faces=[]
 for j in range(N):
  k=(j+1)%N
  faces.append((j,k,2*N+k,2*N+j));faces.append((N+k,N+j,3*N+j,3*N+k))
 bore=.0122 if axis=='X' else .0073
 for L in (L0,L1):
  for r,a in points:
   v=(direction*L*math.cos(root),bore*math.cos(a),bore*math.sin(a))
   if axis=='Z':v=(v[1],v[2],v[0])
   verts.append(v)
 for j in range(N):
  k=(j+1)%N
  faces.extend([(2*N+j,2*N+k,4*N+k,4*N+j),(3*N+k,3*N+j,5*N+j,5*N+k),(4*N+j,4*N+k,5*N+k,5*N+j)])
 for j in range(N):faces.append((j,(j+1)%N,(j+1)%N+N,j+N))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-8);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
 o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);finish(o,name,steel,parent,bevel=.00012)
 for p in me.polygons:p.use_smooth=False
 return o
d=math.atan(2)
bevel_gear('24T left bevel side gear',24,d,.047,.074,left,-1,phase=math.pi/24)
bevel_gear('24T right bevel side gear',24,d,.047,.074,right,1,phase=math.pi/24)
bevel_gear('12T upper spider bevel',12,math.pi/2-d,.047,.074,sat1,1,'Z')
bevel_gear('12T lower spider bevel',12,math.pi/2-d,.047,.074,sat2,-1,'Z')
for side,group in ((-1,left),(1,right)):
 cyl('Splined output half-shaft',.012,.32,(side*.2,0,0),steel,group)
 cyl('Side gear hub',.024,.026,(side*.043,0,0),steel,group)
 for i in range(20):
  a=2*math.pi*i/20
  cyl('Axle spline land',.0016,.035,(side*.075,.012*math.cos(a),.012*math.sin(a)),steel,group,vertices=8)
 # A detached educational wheel is connected by the continuous shaft.
 tire=ring('Wheel tread',.063,.086,side*.36,.038,rubber,group)
 for j in range(3):ring('Tread groove land',.0855,.087,side*.36+(j-1)*.011,.006,rubber,group)
 ring('Wheel rim',.027,.063,side*.36,.027,steel,group)
 for i in range(5):
  a=2*math.pi*i/5
  cyl('Wheel lug',.003,.031,(side*.36,.037*math.cos(a),.037*math.sin(a)),gold,group,vertices=6)
cyl('Spider cross pin',.007,.135,(0,0,0),steel,carrier,'Z')
# Carrier windows keep the engagement zone visible through the inspection cut.
for x in (-.079,.079):
 ring('Carrier cheek',.022,.081,x,.012,iron,carrier)
for a in (0,math.pi):
 cyl('Carrier bridge',.008,.15,(0,.084*math.cos(a),.084*math.sin(a)),iron,carrier)
ring('Crown gear web',.082,.108,-.085,.012,steel,carrier)
# Crown teeth and input spur equivalent, with explicit educational approximation.
# These axes are parallel: the drive is a spur final drive so its mesh is exact involute.
def spur(name,z,module,depth,parent,loc,phase=0):
 rp=z*module/2;rb=rp*math.cos(math.radians(20));rt=rp+module;rr=rp-1.25*module
 inv=lambda r: math.sqrt(max(0,(r/rb)**2-1))-math.acos(min(1,rb/r)) if r>rb else 0
 ip=inv(rp); pts=[]
 for k in range(z):
  rstart=max(rr,rb)
  for sign,rs in ((-1,[rr,rstart,rstart+(rt-rstart)*.33,rstart+(rt-rstart)*.66,rt]),(1,[rt,rstart+(rt-rstart)*.66,rstart+(rt-rstart)*.33,rstart,rr])):
   for r in rs:
    a=k*2*math.pi/z+phase+sign*(.96*math.pi/(2*z)+ip-inv(r));pts.append((r*math.cos(a),r*math.sin(a)))
 N=len(pts);vs=[(x,y,zv) for x in (-depth/2,depth/2) for y,zv in pts]
 fs=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(j,(j+1)%N,(j+1)%N+N,j+N) for j in range(N)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);o.location=loc
 return finish(o,name,steel,parent,.00015)
spur('48T crown final drive',48,.0045,.019,carrier,(-.085,0,0))
pinion=empty('12T input shaft: minus four times carrier speed');pinion.location=(0,.135,0)
spur('12T input pinion',12,.0045,.019,pinion,(-.085,0,0),math.pi/12)
cyl('Input shaft',.009,.13,(-.155,0,0),steel,pinion)
for x in (-.11,.11):
 ring('Bearing outer race',.022,.038,x,.019,steel)
 ring('Bearing inner race',.013,.019,x,.021,steel)
 for i in range(14):
  a=2*math.pi*i/14
  bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=.0047,location=(x,.024*math.cos(a),.024*math.sin(a)))
  finish(bpy.context.object,'Bearing ball',steel,bevel=0)
# Fixed cut housing: rear half and mounting flanges. Inspection edge warm metal.
housing=empty('Fixed cast housing: front removed for inspection')
ring('Sectioned cast shell',.123,.132,0,.20,iron,housing,.3,math.pi)
for x in (-.103,.103):
 ring('Sectioned housing flange',.11,.143,x,.012,iron,housing,.3,math.pi)
 for i in range(1,9):
  a=math.pi*i/8
  cyl('Housing hex bolt',.004,.022,(x,.137*math.cos(a),.137*math.sin(a)),dark,housing,vertices=6)
ring('Copper inspection cut edge',.123,.132,-.103,.0015,gold,housing,.3,math.pi)
for x in (-.08,-.04,0,.04,.08):ring('Cast reinforcement rib',.131,.139,x,.006,iron,housing,.3,math.pi-.09)
for side in (-1,1):
 ring('Housing gasket',.11,.142,side*.11,.0018,rubber,housing,.3,math.pi)
 ring('Output oil seal',.012,.023,side*.123,.006,rubber)
 ring('Thrust washer',.013,.027,side*.059,.0015,gold,carrier)
 for j in range(8):
  a=j*math.pi/4
  cyl('Crown attachment bolt',.0035,.016,(-.088,.087*math.cos(a),.087*math.sin(a)),dark,carrier,vertices=6)
# Ground and cinematic studio illumination.
floor=bpy.data.materials.new('Midnight studio');floor.diffuse_color=(.008,.013,.023,1)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.155));bpy.context.object.data.materials.append(floor)
world=bpy.data.worlds.new('Soft studio ambient');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.13,.18,.25,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4;sc.world=world
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size,color in [('Key',(.1,-.45,.65),38,.5,(.72,.84,1)),('Rim',(-.2,.35,.4),48,.32,(.6,.76,1)),('Warm strip',(.45,.1,.25),26,.24,(1,.71,.42))]:
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color;o=bpy.data.objects.new(name,data);sc.collection.objects.link(o);o.location=loc;aim(o,(0,0,0))
bpy.ops.object.camera_add(location=(.43,-.7,.43));cam=bpy.context.object;cam.name='Inspection camera';cam.data.type='ORTHO';cam.data.ortho_scale=.94;aim(cam,(0,0,0));sc.camera=cam
sc.render.engine='CYCLES';sc.cycles.samples=96;sc.cycles.use_denoising=False;sc.cycles.max_bounces=6;sc.cycles.transparent_max_bounces=4
sc.cycles.use_adaptive_sampling=True;sc.cycles.adaptive_threshold=.035;sc.cycles.adaptive_min_samples=16
sc.render.resolution_x=1080;sc.render.resolution_y=1920;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGB';sc.render.image_settings.compression=15
sc.render.fps=24;sc.frame_start=1;sc.frame_end=1152
sc.view_settings.view_transform='AgX'
# Analytic kinematics, keyed per frame so the blend is independently editable.
# wc=.6 rad/s; transition at 15–19 s to wl=.36, wr=.84. Time-expanded.
def state(t):
 wc=.6
 u=max(0,min(1,(t-15)/4));integ=0 if t<=15 else ((t-15)**2/8 if t<19 else t-17)
 c=wc*t; diff=.24*integ
 return c,c-diff,c+diff,-2*diff
for frame in range(1,1153):
 t=(frame-1)/24;c,l,r,s=state(t)
 for obj,axis,a in ((carrier,0,c),(left,0,l),(right,0,r),(sat1,2,s),(sat2,2,-s),(pinion,0,-4*c)):
  obj.rotation_euler[axis]=a;obj.keyframe_insert('rotation_euler',index=axis,frame=frame)
 # Inspection shell moves away at 3–6 s, exposing interior.
 housing.location.z=max(0,min(1,(t-3)/3))*.26+max(0,min(1,(t-6)/2))*.6;housing.keyframe_insert('location',frame=frame)
 # Wide -> close-up -> wide. Continuous movements within each shot.
 if t<22: scale=1.45; pos=(.43,-.7,.43);target=(0,0,0)
 elif t<34:scale=.35;pos=(.26,-.65,.32);target=(0,0,.015)
 else:scale=1.45;pos=(.43,-.7,.43);target=(0,0,0)
 cam.location=tuple(v*3 for v in pos);aim(cam,target);cam.data.ortho_scale=scale;cam.keyframe_insert('location',frame=frame);cam.keyframe_insert('rotation_euler',frame=frame);cam.data.keyframe_insert('ortho_scale',frame=frame)
for obj in (carrier,left,right,sat1,sat2,pinion,housing,cam,cam.data):
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for kp in fc.keyframe_points:kp.interpolation='LINEAR'
sc.frame_set(241)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'differential.blend'))
sc.render.filepath=str(OUT/'test-overview.png')
if '--render' in sys.argv:bpy.ops.render.render(write_still=True)
