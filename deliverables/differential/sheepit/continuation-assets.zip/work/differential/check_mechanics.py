import bpy,json,math
from pathlib import Path
from mathutils.bvhtree import BVHTree
from mathutils import Vector
sc=bpy.context.scene
names=['24T left bevel side gear','24T right bevel side gear','12T upper spider bevel','12T lower spider bevel','48T crown final drive','12T input pinion','Carrier bridge','Carrier bridge.001','Sectioned cast shell']
rows=[]
for f in range(1,1153):
 sc.frame_set(f);c=bpy.data.objects['Carrier and crown: common rigid body'].rotation_euler.x;l=bpy.data.objects['Left side gear and axle'].rotation_euler.x;r=bpy.data.objects['Right side gear and axle'].rotation_euler.x
 assert abs(l+r-2*c)<1e-5
 pin=bpy.data.objects['12T input shaft: minus four times carrier speed'].rotation_euler.x
 assert abs(pin+4*c)<1e-5
 # Continuous flank contact is visually checked separately; triangle overlap is a conservative warning.
 if f not in [1,121,361,433,529,601,721,901,1152] and f%24:continue
 trees=[]
 for name in names:
  obj=bpy.data.objects[name];me=obj.data;trees.append(BVHTree.FromPolygons([obj.matrix_world@v.co for v in me.vertices],[list(p.vertices) for p in me.polygons]))
 overlaps={f'{names[i]} / {names[j]}':len(trees[i].overlap(trees[j])) for i,j in [(0,2),(1,2),(0,3),(1,3)]}
 spur_overlap=len(trees[4].overlap(trees[5]))
 structure_overlap=sum(len(trees[i].overlap(trees[j])) for i in (0,1) for j in (6,7))+len(trees[5].overlap(trees[8]))
 gaps={}
 for i,j in [(0,2),(1,2),(0,3),(1,3)]:
  o=bpy.data.objects[names[i]];gaps[f'{i}-{j}']=min(trees[j].find_nearest(o.matrix_world@v.co)[3] for v in o.data.vertices)
 rows.append({'frame':f,'speed_sum_angle_residual':l+r-2*c,'bevel_surface_overlap_pairs':overlaps,'final_drive_overlap_pairs':spur_overlap,'gear_structure_overlap_pairs':structure_overlap,'sampled_vertex_clearance_m':gaps})
Path('/workspace/c-mo-funciona-YT/work/differential/mechanics.json').write_text(json.dumps(rows,indent=2))
assert all(max(row['bevel_surface_overlap_pairs'].values())==0 and row['final_drive_overlap_pairs']==0 and row['gear_structure_overlap_pairs']==0 for row in rows),'Gear surfaces intersect; do not start production'
print(json.dumps(rows,indent=2))
