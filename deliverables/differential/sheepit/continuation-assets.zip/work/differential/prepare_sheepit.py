import bpy,json,hashlib
from pathlib import Path
out=Path('/workspace/c-mo-funciona-YT/output/differential/sheepit');out.mkdir(exist_ok=True)
s=bpy.context.scene
s.render.engine='CYCLES';s.cycles.samples=96;s.cycles.use_denoising=True
s.cycles.denoising_input_passes='RGB_ALBEDO_NORMAL';s.cycles.denoising_prefilter='ACCURATE'
s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.035;s.cycles.adaptive_min_samples=16
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
s.render.fps=24;s.frame_start=1;s.frame_end=1152;s.frame_step=1
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8'
s.render.filepath='//frames/differential_';s.render.use_file_extension=True
s.render.use_compositing=True;s.render.use_sequencer=False
s.use_nodes=True;n=s.node_tree;n.nodes.clear();r=n.nodes.new('CompositorNodeRLayers');c=n.nodes.new('CompositorNodeComposite');n.links.new(r.outputs['Image'],c.inputs['Image'])
for vl in s.view_layers:vl.cycles.denoising_store_passes=False
s.frame_set(1)
bpy.ops.file.pack_all()
assert not [im for im in bpy.data.images if im.source=='FILE' and not im.packed_file]
assert not bpy.data.libraries
assert not bpy.app.handlers.frame_change_pre and not bpy.app.handlers.frame_change_post
file=out/'The_Physics_Within_Differential_SheepIt.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(file),compress=True)
report={'blender_version':bpy.app.version_string,'resolution':[1080,1920],'fps':24,'frames':[1,1152],'engine':'CYCLES','denoiser':'OPENIMAGEDENOISE','max_samples':96,'adaptive_threshold':.035,'external_assets':0,'animation_baked':True,'requires_python_scripts':False,'contains':'3D animation only; English 2D overlays and audio are composed separately','sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
(out/'settings.json').write_text(json.dumps(report,indent=2))
(out/'LEEME.txt').write_text('SUBIR A SHEEPIT\n\nArchivo: The_Physics_Within_Differential_SheepIt.blend\nCreado con Blender 4.3.2; elegir una version compatible que SheepIt ofrezca.\n1080 x 1920 nativo, 24 fps, fotogramas 1-1152, Cycles, PNG RGB.\n96 muestras maximas adaptativas, minimo 16, umbral 0.035.\nDenoising OIDN integrado con albedo y normales.\nSin recursos externos, simulaciones por hornear, scripts ni rutas absolutas de salida.\n\nEsta escena produce SOLO la animacion 3D. La narracion, musica, subtitulos y diagramas 2D se componen despues.\nDescargar la secuencia completa de PNG, conservando su orden y numeracion para el montaje posterior.\n\nNo se ha subido nada a SheepIt ni se ha iniciado ningun render externo.\nEl Blender de este entorno no incluye OIDN integrado: no se ha probado aqui el denoising de esta copia, que requiere una compilacion estandar de Blender con OIDN.\n')
print(json.dumps(report))
